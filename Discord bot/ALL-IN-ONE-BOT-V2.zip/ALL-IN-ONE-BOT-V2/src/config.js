require("dotenv").config();

module.exports = {
    token:
        process.env.TOKEN ||
        "MTA5ODc0MTIwNzQxNDM2MjE5Mw.G5FvIn.l1AyNXontFmNh1NH8Ax8f4jBpIrECmnHQLi_ts",
    clientID: process.env.CLIENT_ID || "1098741207414362193",
    prefix: process.env.PREFIX || "+",
    ownerID: process.env.OWNER_ID || "1092061892568174723",
    guildID: process.env.GUILD_ID || "1247444478512336896",
    SpotifyID: process.env.SPOTIFY_ID || "6c31645ffb004ab8b44d06f7b96d1b66",
    SpotifySecret:
        process.env.SPOTIFY_SECRET || "3618fdc0b4824cfd91a8d425dac32987",
    mongourl:
        process.env.MONGO_URL ||
        "mongodb+srv://b12nsj:99c61q@cluster0.wequneh.mongodb.net/?retryWrites=true&w=majority",
    embedColor: process.env.EMBED_COLOR || 0xcc0000,
    logs: process.env.LOGS || "1247444478860595248",
    logs1: process.env.LOGS1 || "1247444478860595248",
    errorLogsChannel: process.env.ERROR_LOGS_CHANNEL || "1247444478860595248",
    buglogschannel: process.env.BUG_LOGS_CHANNEL || "1247444478860595248",
    SearchPlatform: "youtube",
    AggregatedSearchOrder:
        process.env.AGGREGATED_SEARCH_ORDER ||
        "youtube ,youtube music,youtube,soundcloud",
    links: {
        img:
            process.env.IMG ||
            "https://discord.com/channels/1247444478512336896/1247444478713659421/1254450678152167425",
        support: process.env.SUPPORT || "https://discord.gg/rolee",
        invite:
            process.env.INVITE ||
            "https://discord.com/oauth2/authorize?client_id=1256582795908747365&permissions=8&integration_type=0&scope=bot",
    },
    nodes: [
        {
            host: process.env.NODE_HOST || "ambani.ncop.tech",
            port: parseInt(process.env.NODE_PORT || "2334"),
            password: process.env.NODE_PASSWORD || "ambaniop",
            secure: parseBoolean(process.env.NODE_SECURE || "false"),
        },
    ],
};

function parseBoolean(value) {
    if (typeof value === "string") {
        value = value.trim().toLowerCase();
    }
    switch (value) {
        case true:
        case "true":
            return true;
        default:
            return false;
    }
}
