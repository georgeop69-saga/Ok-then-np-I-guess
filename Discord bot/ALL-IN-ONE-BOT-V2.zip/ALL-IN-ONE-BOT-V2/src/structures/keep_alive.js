const http = require('http');

const server = http.createServer((req, res) => {
  res.setHeader('Content-Type', 'text/html');
  res.end(`
    <html>
      <head>
        <title>Your Web View</title>
      </head>
      <body style="margin: 0; padding: 0;">
        <iframe width="100%" height="100%" src="https://axocoder.vercel.app/" frameborder="0" allowfullscreen></iframe>
      </body>
    </html>`);
});

const fixedPort = 3000;

server.listen(fixedPort, () => {
  console.log(`Server Online because of Axo Coder ✅!! Listening on port ${fixedPort}`);
});

server.on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    console.log(`Port ${fixedPort} is already in use, trying another port...`);
    const randomPort = Math.floor(Math.random() * (4000 - 3000 + 1)) + 3000;
    server.listen(randomPort, () => {
      console.log(`Server Online because of Axo Coder ✅!! Listening on port ${randomPort}`);
    });
  } else {
    console.error(`Server error: ${err.message}`);
  }
});
